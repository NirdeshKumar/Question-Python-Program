

#Example 12: ***********************Vowel check***************************


vow=input("enter a alphabates: ")
if(vow=='A' or vow=='E' or vow=='I' or vow=='O' or vow=='U' or vow=='a' or vow=='e' or vow=='i' or vow=='o' or vow=='u'):
 print(f"{vow} is vowel ")
else:
 print(f"{vow} is consonent ")

