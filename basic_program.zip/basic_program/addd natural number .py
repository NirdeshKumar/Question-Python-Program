
#Example 15:********************************** add natural number*************************

val=int(input("enter a value : "))
sum=0
for i in range(1,val+1):
 sum +=i
 print(sum)
print(sum)
