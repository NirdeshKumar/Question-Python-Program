

#Example 11: **********************Driving License***************

age=int(input("enter your age : "))
if (age>=18 and age<60):
 print("you are eligible. ")
elif(age<18):
 print("sabr kr  ")
else:
 print("tumari umar nhi hai abhi chalane ki")
  
