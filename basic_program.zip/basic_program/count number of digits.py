#Example 2: Python program to count the total number of digits in a number.
val=input("enter a number: ")
#s=str(val)
c=0
for i in val:
    c += 1
print(c) 
