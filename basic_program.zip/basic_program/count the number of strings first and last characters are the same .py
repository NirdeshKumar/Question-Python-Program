
a=[1,2,3,4,5,3,2,6,7,4]
c=[]
for i in a:
    if(i not in c):
        c.append(i)
print(c)
