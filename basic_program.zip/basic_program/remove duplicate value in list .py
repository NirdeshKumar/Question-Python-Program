

# Python program to capitalize the first character of each word in a string.


a=input("enter : ").split()
#a=['nirdesh','kumar']
for i in a:
    print(i.capitalize(),end=' ')
