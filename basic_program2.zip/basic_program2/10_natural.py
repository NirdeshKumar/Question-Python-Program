#     Print the first 10 natural numbers using for loop.
for i in range(1,11):
 print(i)
