ch=input("enter a Anything : ")
if(len(ch)>1 and ch != ""):
  print("word")
elif(" " in ch):
 print("Sentence")
else:
 print("character")