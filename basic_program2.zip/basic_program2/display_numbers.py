#Example 6: Python program to display numbers from a list using a for loop.

a=[12,34,23,65,45,3,356,45,90]
for i in a:
 print(i)