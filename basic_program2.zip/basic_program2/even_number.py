#Example 2: Python program to print all the even numbers within the given range.

val=int(input("enter a value: "))
for i in range(2,val+1,2):
 print(i)
 