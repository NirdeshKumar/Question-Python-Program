#********************************** factorial number*************************

val=int(input("enter a valur: "))
fact=1
for x in range(1,val+1):
 fact *=x
print(fact)


