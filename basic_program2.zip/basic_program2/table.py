var=int(input("no.:"))
for i in range(1,11):
 print(f"{var} * {i} = ",var*i)